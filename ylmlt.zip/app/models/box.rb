class Box < ApplicationRecord

end
