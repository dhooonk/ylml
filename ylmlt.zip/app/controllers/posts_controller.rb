class PostsController < ApplicationController
  def index 

  end

  def new
  end
end
